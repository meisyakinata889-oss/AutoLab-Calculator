from flask import Flask, render_template, request

app = Flask(__name__)

CONVERSIONS = {
    "current": {
        "label": "Current — Arus",
        "units": ["mA", "A"],
        "to_base": {"mA": 0.001, "A": 1},
    },
    "voltage": {
        "label": "Voltage — Tegangan",
        "units": ["mV", "V"],
        "to_base": {"mV": 0.001, "V": 1},
    },
    "resistance": {
        "label": "Resistance — Resistansi",
        "units": ["Ω", "kΩ"],
        "to_base": {"Ω": 1, "kΩ": 1000},
    },
    "frequency": {
        "label": "Frequency — Frekuensi",
        "units": ["Hz", "kHz"],
        "to_base": {"Hz": 1, "kHz": 1000},
    },
}


@app.route("/", methods=["GET", "POST"])
def index():
    category = "current"
    input_value = ""
    from_unit = "mA"
    to_unit = "A"
    result = None
    factor = None
    error = None

    if request.method == "POST":
        category = request.form.get("category", "current")
        if category not in CONVERSIONS:
            category = "current"
            error = "Kategori konversi tidak valid."

        config = CONVERSIONS[category]
        units = config["units"]
        input_value = request.form.get("value", "").strip()
        from_unit = request.form.get("from_unit", units[0])
        to_unit = request.form.get("to_unit", units[1])

        if from_unit not in units or to_unit not in units:
            error = "Pilihan satuan tidak valid."
        elif not input_value:
            error = "Masukkan nilai yang ingin dikonversi."
        else:
            try:
                number = float(input_value)
                if not (-1e100 < number < 1e100):
                    raise ValueError("Nilai terlalu besar atau tidak valid.")

                base_value = number * config["to_base"][from_unit]
                converted = base_value / config["to_base"][to_unit]
                factor_value = (
                    config["to_base"][from_unit]
                    / config["to_base"][to_unit]
                )

                result = f"{converted:.10g}"
                factor = f"{factor_value:.10g}"
            except ValueError:
                error = "Masukkan angka yang valid dan tidak terlalu besar."

    config = CONVERSIONS[category]
    return render_template(
        "index.html",
        categories=CONVERSIONS,
        category=category,
        units=config["units"],
        input_value=input_value,
        from_unit=from_unit,
        to_unit=to_unit,
        result=result,
        factor=factor,
        error=error,
    )


if __name__ == "__main__":
    app.run(debug=True)
