# AutoLab Calculator

A simple electrical unit converter built with Python and Flask.

## Features
- Current conversion (mA ↔ A)
- Voltage conversion (mV ↔ V)
- Resistance conversion (Ω ↔ kΩ)
- Frequency conversion (Hz ↔ kHz)
- Input validation and conversion factor display
- Responsive dark interface

## Technologies
- Python
- Flask
- HTML
- CSS

## Run locally
1. Install Python.
2. Install dependencies:
   ```bash
   python -m pip install -r requirements.txt
   ```
3. Start the app:
   ```bash
   python app.py
   ```
4. Open http://127.0.0.1:5000 in your browser.
